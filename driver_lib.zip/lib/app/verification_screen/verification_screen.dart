import 'package:driver/constant/constant.dart';
import 'package:driver/controllers/verification_controller.dart';
import 'package:driver/models/document_model.dart';
import 'package:driver/models/driver_document_model.dart';
import 'package:driver/themes/app_them_data.dart';
import 'package:driver/utils/dark_theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import 'verification_details_upload_screen.dart';

class VerificationScreen extends StatelessWidget {
  const VerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeChange = Provider.of<DarkThemeProvider>(context);
    return GetBuilder<VerificationController>(
        init: VerificationController(),
        builder: (controller) {
          return Scaffold(
            backgroundColor: themeChange.getThem()
                ? AppThemeData.surfaceDark
                : AppThemeData.surface,
            body: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: controller.isLoading.value
                  ? Constant.loader()
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Document Verification".tr,
                          style: TextStyle(
                              color: themeChange.getThem()
                                  ? AppThemeData.grey100
                                  : AppThemeData.grey800,
                              fontFamily: AppThemeData.bold,
                              fontSize: 22),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Upload your ID Proof to complete the verification process and ensure compliance."
                              .tr,
                          style: TextStyle(
                              fontSize: 14,
                              color: themeChange.getThem()
                                  ? AppThemeData.grey200
                                  : AppThemeData.grey700,
                              fontFamily: AppThemeData.regular),
                        ),
                        const SizedBox(
                          height: 40,
                        ),
                        Container(
                          decoration: ShapeDecoration(
                            color: themeChange.getThem()
                                ? AppThemeData.grey900
                                : AppThemeData.grey50,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 20),
                            child: ListView.separated(
                              itemCount: controller.documentList.length,
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              itemBuilder: (context, index) {
                                DocumentModel documentModel =
                                    controller.documentList[index];
                                Documents documents = Documents();

                                var contain = controller.driverDocumentList
                                    .where((element) =>
                                        element.documentId == documentModel.id);
                                if (contain.isNotEmpty) {
                                  documents = controller.driverDocumentList
                                      .firstWhere((itemToCheck) =>
                                          itemToCheck.documentId ==
                                          documentModel.id);
                                }

                                return InkWell(
                                  onTap: () {
                                    Get.to(const VerificationDetailsUploadScreen(),
                                            arguments: {
                                          'documentModel': documentModel
                                        })!
                                        .then(
                                      (value) {
                                        if (value == true) {
                                          controller.getDocument();
                                        }
                                      },
                                    );
                                  },
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${documentModel.title}",
                                              style: TextStyle(
                                                color: themeChange.getThem()
                                                    ? AppThemeData.grey100
                                                    : AppThemeData.grey800,
                                                fontFamily: AppThemeData.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "${documentModel.frontSide == true ? "Front" : ""} ${documentModel.backSide == true ? "And Back" : ""} ${'Photo'.tr}",
                                              style: TextStyle(
                                                color: themeChange.getThem()
                                                    ? AppThemeData.grey300
                                                    : AppThemeData.grey600,
                                                fontFamily:
                                                    AppThemeData.regular,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 6),
                                        child: Text(
                                          documents.status == "approved"
                                              ? "Verified".tr
                                              : documents.status == "rejected"
                                                  ? "Rejected".tr
                                                  : documents.status ==
                                                          "uploaded"
                                                      ? "Uploaded".tr
                                                      : "Pending".tr,
                                          style: TextStyle(
                                              color:
                                                  documents.status == "approved"
                                                      ? Colors.green
                                                      : documents.status ==
                                                              "rejected"
                                                          ? Colors.red
                                                          : documents.status ==
                                                                  "uploaded"
                                                              ? AppThemeData
                                                                  .primary300
                                                              : Colors.orange,
                                              fontFamily: AppThemeData.medium,
                                              fontSize: 16),
                                        ),
                                      ),
                                      const Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 20,
                                      )
                                    ],
                                  ),
                                );
                              },
                              separatorBuilder:
                                  (BuildContext context, int index) {
                                return const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  child: Divider(),
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          );
        });
  }
}

/*******************************************************************************************
* Copyright (c) 2025 Movenetics Digital. All rights reserved.
*
* This software and associated documentation files are the property of 
* Movenetics Digital. Unauthorized copying, modification, distribution, or use of this 
* Software, via any medium, is strictly prohibited without prior written permission.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
* PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
* OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
* OTHER DEALINGS IN THE SOFTWARE.
*
* Company: Movenetics Digital
* Author: Aman Bhandari 
*******************************************************************************************/

